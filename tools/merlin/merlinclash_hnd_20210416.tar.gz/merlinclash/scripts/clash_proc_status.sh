#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
ipv6_flag="0"

ipv6_mode(){
	[ -n "$(ip addr | grep -w inet6 | awk '{print $2}')" ] && echo true || echo false
}

echo_version() {
	if [ "$merlinclash_ipv6switch" == "1" ] && [ $(ipv6_mode) == "true" ]; then
			ipv6_flag="1"
	fi
	echo_date
	SOFVERSION=$(cat /koolshare/merlinclash/version)
	
	
	echo ① 程序版本（插件版本：$SOFVERSION）：
	echo -----------------------------------------------------------
	echo "程序			版本		备注"
	echo "clash			$merlinclash_clash_version"
	echo "UnblockNeteaseMusic	$merlinclash_UnblockNeteaseMusic_version"
	echo "koolproxy		$merlinclash_koolproxy_version"
	echo -----------------------------------------------------------
}

check_status() {
	#echo
	pid_clash=$(pidof clash)
	watchdog=$(cru l | grep clash_watchdog |awk -F"#" '{print $2}')
	#pid_watchdog=$(ps | grep clash_watchdog.sh | grep -v grep | awk '{print $1}')
	DMQ=$(pidof dnsmasq)
	kcp=$(pidof client_linux_arm64)
	ubm=$(pidof UnblockNeteaseMusic)
	kp=$(pidof koolproxy)
	echo_version
	echo
	echo ② 检测当前相关进程工作状态：（你正在使用clash）
	echo -----------------------------------------------------------
	echo "程序		状态	PID"
	[ -n "$pid_clash" ] && echo "clash		工作中	pid：$pid_clash" || echo "clash		未运行"
	[ -n "$watchdog" ] && echo "看门狗		工作中	" || echo "看门狗		未运行"
	[ -n "$DMQ" ] && echo "dnsmasq		工作中	pid：$DMQ" || echo "dnsmasq		未运行"
	[ -n "$kcp" ] && echo "kcp		工作中	pid：$kcp" || echo "kcp		未运行"
	[ -n "$ubm" ] && echo "网易云音乐解锁	工作中	pid：$ubm" || echo "网易云音乐解锁	未运行"
	[ -n "$kp" ] && echo "KidsProtect	工作中	pid：$kp" || echo "KidsProtect	未运行"
	echo -----------------------------------------------------------
	echo
	echo ③ 检测iptbales工作状态：
	echo ------------------------------------------------------ nat表 PREROUTING 链 ---------------------------------------------------------
	iptables -nvL PREROUTING -t nat --line-number
	echo ------------------------------------------------------- nat表 OUTPUT 链 ------------------------------------------------------------
	iptables -nvL OUTPUT -t nat --line-number
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo ----------------------------------------------------------- KOOLPROXY --------------------------------------------------------------
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo ------------------------------------------------------ nat表 KOOLPROXY 链 ----------------------------------------------------------
	[ "$merlinclash_koolproxy_enable" == "1" ] && iptables -nvL KOOLPROXY -t nat --line-number
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo -------------------------------------------------------- nat表 KP_HTTP 链 ----------------------------------------------------------
	[ "$merlinclash_koolproxy_enable" == "1" ] && iptables -nvL KP_HTTP -t nat --line-number
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo ------------------------------------------------------ nat表 KP_HTTPS 链 -----------------------------------------------------------
	[ "$merlinclash_koolproxy_enable" == "1" ] && iptables -nvL KP_HTTPS -t nat --line-number
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo ------------------------------------------------------ UnblockNeteaseMusic ---------------------------------------------------------
	[ "$merlinclash_koolproxy_enable" == "1" ] && echo
	[ "$merlinclash_unblockmusic_enable" == "1" ] && echo ------------------------------------------------------ nat表 cloud_music 链 ---------------------------------------------------------
	[ "$merlinclash_unblockmusic_enable" == "1" ] && iptables -nvL cloud_music -t nat --line-number
	[ "$merlinclash_unblockmusic_enable" == "1" ] && echo ------------------------------------------------------ nat表 UNM_service 链 ---------------------------------------------------------
	[ "$merlinclash_unblockmusic_enable" == "1" ] && iptables -nvL UNM_service -t nat --line-number
	echo
	echo ---------------------------------------------------------- MerlinClash -------------------------------------------------------------
	echo
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && echo ------------------------------------------------------ nat表 merlinclash 链 ---------------------------------------------------------
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && iptables -nvL merlinclash -t nat --line-number
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && echo ----------------------------------------------------- nat表 merlinclash_NOR 链 --------------------------------------------------------
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && iptables -nvL merlinclash_NOR -t nat --line-number
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && echo ----------------------------------------------------- nat表 merlinclash_CHN 链 --------------------------------------------------------
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && iptables -nvL merlinclash_CHN -t nat --line-number
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && echo ----------------------------------------------------- nat表 merlinclash_EXT 链 --------------------------------------------------------
	[ "$merlinclash_tproxymode" == "closed" ] || [ "$merlinclash_tproxymode" == "udp" ] && iptables -nvL merlinclash_EXT -t nat --line-number
	[ "$merlinclash_tproxymode" != "closed" ] && echo ------------------------------------------------------ mangle表 PREROUTING 链 ---------------------------------------------------------
	[ "$merlinclash_tproxymode" != "closed" ] && iptables -nvL PREROUTING -t mangle --line-number
	[ "$merlinclash_tproxymode" != "closed" ] && echo -------------------------------------------------------- mangle表 OUTPUT 链 -----------------------------------------------------------
	[ "$merlinclash_tproxymode" != "closed" ] && iptables -nvL OUTPUT -t mangle --line-number
	[ "$merlinclash_tproxymode" != "closed" ] && echo ------------------------------------------------------ mangle表 merlinclash 链 ---------------------------------------------------------
	[ "$merlinclash_tproxymode" != "closed" ] && iptables -nvL merlinclash -t mangle --line-number
	[ "$merlinclash_tproxymode" != "closed" ] && [ "$merlinclash_iptablessel" == "fangan1" ] && echo ----------------------------------------------------- mangle表 merlinclash_PREROUTING 链 --------------------------------------------------------
	[ "$merlinclash_tproxymode" != "closed" ] && [ "$merlinclash_iptablessel" == "fangan1" ] && iptables -nvL merlinclash_PREROUTING -t mangle --line-number
	[ "$merlinclash_tproxymode" != "closed" ] && [ "$merlinclash_iptablessel" == "fangan2" ] && echo ----------------------------------------------------- mangle表 merlinclash_NOR 链 --------------------------------------------------------
	[ "$merlinclash_tproxymode" != "closed" ] && [ "$merlinclash_iptablessel" == "fangan2" ] && iptables -nvL merlinclash_NOR -t mangle --line-number
	[ "$merlinclash_tproxymode" != "closed" ] && [ "$merlinclash_iptablessel" == "fangan2" ] && echo ----------------------------------------------------- mangle表 merlinclash_CHN 链 --------------------------------------------------------
	[ "$merlinclash_tproxymode" != "closed" ] && [ "$merlinclash_iptablessel" == "fangan2" ] && iptables -nvL merlinclash_CHN -t mangle --line-number
	[ "$ipv6_flag" == "1" ] && echo ---------------------------------------------------------- MerlinClash-ipv6 -------------------------------------------------------------
	[ "$ipv6_flag" == "1" ] && echo ------------------------------------------------------ ipv6-mangle表 PREROUTING 链 ---------------------------------------------------------
	[ "$ipv6_flag" == "1"  ] && ip6tables -nvL PREROUTING -t mangle --line-number
	[ "$ipv6_flag" == "1"  ] && echo -------------------------------------------------------- ipv6-mangle表 OUTPUT 链 -----------------------------------------------------------
	[ "$ipv6_flag" == "1"  ] && ip6tables -nvL OUTPUT -t mangle --line-number
	[ "$ipv6_flag" == "1"  ] && echo ------------------------------------------------------ ipv6-mangle表 merlinclash 链 ---------------------------------------------------------
	[ "$ipv6_flag" == "1"  ] && ip6tables -nvL merlinclash -t mangle --line-number
	[ "$ipv6_flag" == "1"  ] && [ "$merlinclash_iptablessel" == "fangan1" ] && echo ----------------------------------------------------- ipv6-mangle表 merlinclash_PREROUTING 链 --------------------------------------------------------
	[ "$ipv6_flag" == "1"  ] && [ "$merlinclash_iptablessel" == "fangan1" ] && ip6tables -nvL merlinclash_PREROUTING -t mangle --line-number
	[ "$ipv6_flag" == "1"  ] && [ "$merlinclash_iptablessel" == "fangan2" ] && echo ----------------------------------------------------- ipv6-mangle表 merlinclash_NOR 链 --------------------------------------------------------
	[ "$ipv6_flag" == "1"  ] && [ "$merlinclash_iptablessel" == "fangan2" ] && ip6tables -nvL merlinclash_NOR -t mangle --line-number
	[ "$ipv6_flag" == "1"  ] && [ "$merlinclash_iptablessel" == "fangan2" ] && echo ----------------------------------------------------- ipv6-mangle表 merlinclash_CHN 链 --------------------------------------------------------
	[ "$ipv6_flag" == "1"  ] && [ "$merlinclash_iptablessel" == "fangan2" ] && ip6tables -nvL merlinclash_CHN -t mangle --line-number
	echo -----------------------------------------------------------------------------------------------------------------------------------
	echo
}

if [ "$merlinclash_enable" == "1" ]; then
	check_status >/tmp/upload/clash_proc_status.txt 2>&1
	#echo XU6J03M6 >> /tmp/upload/ss_proc_status.txt
else
	echo 插件尚未启用！ >/tmp/upload/clash_proc_status.txt 2>&1
fi

http_response $1
