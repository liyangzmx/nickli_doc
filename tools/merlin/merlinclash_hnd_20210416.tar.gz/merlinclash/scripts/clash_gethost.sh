#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#
rm -rf /tmp/upload/$merlinclash_hostsel.txt
ln -sf /koolshare/merlinclash/yaml_basic/host/$merlinclash_hostsel.yaml /tmp/upload/$merlinclash_hostsel.txt

http_response $1

